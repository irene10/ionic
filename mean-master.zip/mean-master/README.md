# mean
Project with examples of how to use the MEAN Stack (MONGODB, EXPRESS JS, ANGULAR JS, NODE JS)
