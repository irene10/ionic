app.controller("peopleController", function($scope, peopleService){

	$scope.orderByString = 'fname';
	$scope.people = [];

	peopleService.getPeople().success(function(data){

		$scope.people = data;

	});

	//SHOW ALL PEOPLE
	$scope.showAll = function(){

		peopleService.getPeople().success(function(data){

		$scope.people = data;
		$scope.show = false;
		

		});

	};

	//ADD PEOPLE
	$scope.addPeople = function(){

		var peopleData = {

			fname:$scope.data.fname,
			lname:$scope.data.lname

		};

		peopleService.postPeople(peopleData).success(function(data){

			console.log("People Inserted: " + data);
			$scope.data = {};
			$scope.showAll();

		});

	};

	//REMOVE PEOPLE
	$scope.removePeople = function(id){

		peopleService.deletePeople(id).success(function(data){

			console.log("ID Removed: " + data);
			$scope.showAll();

		});

	};

	//ORDER BY FUNCTION
	$scope.orderBy = function(x){

		$scope.orderByString = x;

	};

	//FORM SHOW/HIDE
	$scope.showForm = function(state){

		$scope.show = state;

	}


});