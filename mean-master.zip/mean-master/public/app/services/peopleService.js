app.factory('peopleService',function($http){


	var peopleFactory = {};

	
	peopleFactory.getPeople = function(){

		return $http.get('http://localhost:8383/api/people');

	};

	peopleFactory.postPeople = function(data){

		return $http.post('http://localhost:8383/api/people', data);

	};

	peopleFactory.deletePeople = function(id){

		return $http.delete('http://localhost:8383/api/people/'+id);

	};



	return peopleFactory;
});
