app.factory('languageService',function($http){


	var languagesFactory = {};

	languagesFactory.getAllLanguages = function(){

		return $http.get('http://localhost:8383/api/languages');

	};

	return languagesFactory;
});
