//REQUIRING ALL THE NEEDED MODULES AND LIBRARIES
var express = require('express'), //express framework module
fs = require('fs'), //fs - filesystem module
path = require('path'), // path module
bodyParser = require('body-parser'),
morgan = require('morgan'); //to log on console
var jwt = require('jsonwebtoken'); //to use token authentication
var config = require('./config'); //config file
var app = express(); //instanciating express
var port = config.port; //port to use

//MIDDLEWARES
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


//HANDLE CORS
app.use(function(req, res, next) {
res.setHeader('Access-Control-Allow-Origin', '*');
res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type, \
Authorization');
next();
});

//LOG TO CONSOLE WITH MORGAN
app.use(morgan('dev'));


//API ROUTES
var apiRouter = require('./app/routes/api')(app, express);
app.use('/api', apiRouter);


//CATCHALL ROUTES
app.use(express.static(__dirname + '/public'));
app.get('*', function(req, res){

	res.sendFile(path.join(__dirname, '/public/app/views/pages/index.html'));

});

//LISTEN TO PORT
app.listen(port);
console.log("Server Running at http://localhost:" + port);