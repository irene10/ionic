app.controller("languagesController", function($scope, languageService){

	//var vm = this;

	$scope.languages = [];

	languageService.getAllLanguages().success(function(data){

		$scope.languages = data;

	});

	$scope.addLanguage = function(){

		$scope.languages.push({

			name:$scope.data.name,
			

		});

		$scope.data = {};

	};
	

});