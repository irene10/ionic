var mongojs = require('mongojs');
var languagesdb = mongojs('languages',['languages']);
var peopledb = mongojs('people',['people']);


module.exports = function(app, express) {
var apiRouter = express.Router();

/*
//TOKEN MIDDLEWARE

apiRouter.use(function(req, res, next) {

// check header or url parameters or post parameters for token

var token = req.body.token || req.param('token') || req.headers['x-access-toke\n'];

// decode token

if (token) {

// verifies secret and checks exp

	jwt.verify(token, "superSecret", function(err, decoded) {

	if (err) {

		return res.status(403).send({

		success: false,

		message: 'Failed to authenticate token.'

		});

	} else {

// if everything is good, save to request for use in other routes

	req.decoded = decoded;

	next();

	}

	});

	} else {

// if there is no token

// return an HTTP response of 403 (access forbidden) and an error message

		return res.status(403).send({

		success: false,
		message: 'No token provided.'

	});
 }
 });


//END TOKEN MIDDLEWARE
*/



/*
START PEOPLE ROUTES
*/

//Select all people
apiRouter.get('/people', function(req, res){

	peopledb.people.find(function(err, docs){

		if(err){
			res.send(err);
		}

		res.json(docs);

	});

});

//Save people Record in DB
apiRouter.post('/people', function(req, res){

	var data = {

		fname: req.body.fname,
		lname: req.body.lname,

	};

	peopledb.people.insert(data, function(err, result){

		if(err){
			res.json(err);
		}

		res.json({message:"Record Saved"});

	});
	

});

//Remove people Record in DB
apiRouter.delete('/people/:id', function(req, res){

	 peopledb.people.remove({
     _id: mongojs.ObjectId(req.params.id)
     }, function(err){

		if(err){
			res.json(err);
		}

		res.json({message:"Record Removed"});

	});


});

/*
END PEOPLE ROUTES
*/

//Select all languages
apiRouter.get('/languages', function(req, res){

	languagesdb.languages.find(function(err, docs){

		if(err){
			res.send(err);
		}

		res.json(docs);

	});

});

//Select languages by name
apiRouter.get('/languages/:name', function(req, res){

	languagesdb.languages.findOne({name: req.params.name},

	 function(err, doc){

		if(err){
			res.send(err);
		}

		res.json(doc);

	});

});

//Insert Language

apiRouter.post('/languages', function(req, res){

	languagesdb.languages.insert(req.body,

	 function(err){

		if(!err){
			res.json({message: 'Language Saved!'});
		}

	});

});


//Update Language
apiRouter.put('/languages', function(req, res){

	res.send("PUT METHOD");
});



//Delete Language
apiRouter.delete('/languages', function(req, res){

	res.send("DELETE METHOD");

});


/*
apiRouter.post('/auth', function(req, res) {

	if(req.body.username == "rhina"){

		var token = jwt.sign({

			username: req.body.username,
			
		}, "superSecret", {

		expiresInMinutes: 1440 // expires in 24 hours

		});

		// return the information including token as JSON

		res.json({

		success: true,

		message: 'Enjoy your token!',

		token: token

		});

	}else{

		res.json({

		success: false,

		message: 'Authentication Fail!',

		});

	}

});
*/

return apiRouter;
};